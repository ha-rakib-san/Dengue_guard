/* DengueGuard — frontend logic
 * Connected to Node.js Express + PostgreSQL Backend
 */

const CONFIG = {
  USE_BACKEND: true,
  API_BASE: ""
};


/* ---------- Dummy data (used only if the backend fails) ---------- */

const DUMMY = {

  forecast: {
    Dhaka: [
      { date: "Mon", cases: 142, rainfall: 28, humidity: 84, temp: 29 },
      { date: "Tue", cases: 155, rainfall: 35, humidity: 86, temp: 29 },
      { date: "Wed", cases: 171, rainfall: 42, humidity: 88, temp: 28 },
      { date: "Thu", cases: 168, rainfall: 20, humidity: 82, temp: 30 },
      { date: "Fri", cases: 149, rainfall: 8, humidity: 74, temp: 31 },
      { date: "Sat", cases: 120, rainfall: 3, humidity: 68, temp: 32 },
      { date: "Sun", cases: 135, rainfall: 18, humidity: 78, temp: 30 }
    ]
  },

  areas: [
    { name: "Mirpur", lat: 23.8223, lng: 90.3654, level: "high", cases: 64 },
    { name: "Mohammadpur", lat: 23.7662, lng: 90.3589, level: "high", cases: 58 },
    { name: "Uttara", lat: 23.8759, lng: 90.3795, level: "medium", cases: 31 },
    { name: "Dhanmondi", lat: 23.7461, lng: 90.3742, level: "medium", cases: 27 },
    { name: "Motijheel", lat: 23.7330, lng: 90.4172, level: "medium", cases: 22 },
    { name: "Gulshan", lat: 23.7925, lng: 90.4078, level: "low", cases: 9 },
    { name: "Bashundhara", lat: 23.8193, lng: 90.4526, level: "low", cases: 7 }
  ],

  articles: [
    {
      title: "Clean-Up Day Guide",
      type: "Video",
      source: "YouTube",
      summary: "A short video on clearing mosquito breeding sites around your home.",
      url: "https://www.youtube.com/watch?v=WYuGyDDgYMA"
    },
    {
      title: "Aedes Mosquito Facts",
      type: "Article",
      source: "PubMed Central",
      summary: "Research on when Aedes mosquitoes bite most (morning and early evening) and who they target.",
      url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC11860606/"
    },
    {
      title: "When to See a Doctor",
      type: "Article",
      source: "Cleveland Clinic",
      summary: "Dengue fever symptoms, treatment and when to get medical care.",
      url: "https://my.clevelandclinic.org/health/diseases/17753-dengue-fever"
    }
  ]
};


/* ---------- API layer ---------- */

const api = {

  async get(path, fallback) {

    if (!CONFIG.USE_BACKEND) {
      return fallback;
    }

    try {
      const r = await fetch(CONFIG.API_BASE + path);

      if (!r.ok) {
        throw new Error(r.status);
      }

      return await r.json();

    } catch (e) {
      console.warn("API failed, using fallback data:", path, e);
      return fallback;
    }
  },

  async post(path, body, isForm = false) {

    if (!CONFIG.USE_BACKEND) {
      return { ok: true, local: true };
    }

    const r = await fetch(CONFIG.API_BASE + path, {
      method: "POST",
      headers: isForm ? undefined : { "Content-Type": "application/json" },
      body: isForm ? body : JSON.stringify(body)
    });

    let data = {};

    try {
      data = await r.json();
    } catch (e) {}

    if (!r.ok) {
      throw new Error(data.message || "Request failed (" + r.status + ")");
    }

    return data;
  },

  forecast: (city) =>
    api.get(
      `/api/forecast?city=${encodeURIComponent(city)}`,
      DUMMY.forecast[city] || null
    ),

  areas: () => api.get("/api/risk-areas", DUMMY.areas),

  articles: () => api.get("/api/awareness", DUMMY.articles),

  prevention: () => api.get("/api/prevention", []),

  reports: () => api.get("/api/reports", []),

  stats: () => api.get("/api/stats", null)
};


/* ---------- Helpers ---------- */

const $ = (s) => document.querySelector(s);

const on = (sel, ev, fn) => {
  const el = $(sel);
  if (el) {
    el.addEventListener(ev, fn);
  }
};

const esc = (s) =>
  String(s == null ? "" : s).replace(
    /[&<>"']/g,
    (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[c])
  );

// Only allow http / https links
const safeUrl = (u) => (/^https?:\/\//i.test(u || "") ? u : "#");

const cap = (s) => s[0].toUpperCase() + s.slice(1);


/* ---------- Navbar ---------- */

on("#navToggle", "click", () => {
  $("#navLinks").classList.toggle("open");
});

on("#navLinks", "click", (e) => {
  if (e.target.tagName === "A") {
    $("#navLinks").classList.remove("open");
  }
});


/* ---------- Prevention checklist ---------- */

on("#checklist", "change", () => {

  const boxes = [...document.querySelectorAll("#checklist input")];
  const done = boxes.filter((b) => b.checked).length;

  if ($("#checklistStatus")) {
    $("#checklistStatus").textContent =
      done === boxes.length
        ? "🎉 Great job! Your home is checked."
        : `${done} of ${boxes.length} done`;
  }
});


/* ---------- Prevention content (from PostgreSQL) ---------- */

async function renderPrevention() {

  if (!$("#preventionCards") || !$("#checklist")) {
    return;
  }

  const list = await api.prevention();

  // If the database has nothing, keep the HTML that is already on the page
  if (!list.length) {
    return;
  }

  const cards = list.filter((i) => i.type !== "Checklist");
  const checks = list.filter((i) => i.type === "Checklist");

  $("#preventionCards").innerHTML = cards.map((item) => `
    <article class="card">
      <h3>${esc(item.title)}</h3>
      <p>${esc(item.description)}</p>
    </article>
  `).join("");

  if (checks.length) {
    $("#checklist").innerHTML = checks.map((item) => `
      <li>
        <label>
          <input type="checkbox"> ${esc(item.title)}
        </label>
      </li>
    `).join("");

    if ($("#checklistStatus")) {
      $("#checklistStatus").textContent = "";
    }
  }
}


/* ---------- Symptom screening ---------- */

/* Symptom IDs (must match the symptoms table):
 * 1 Fever, 2 Headache, 3 Pain behind eyes, 4 Muscle/joint pain,
 * 5 Rash, 6 Nausea/vomiting, 7 Bleeding
 */
function assessSymptoms(selected) {

  const has = (id) => selected.includes(id);

  // headache, eye pain, muscle/joint pain, rash, nausea/vomiting
  const matches = [2, 3, 4, 5, 6].filter(has).length;

  if (has(7) || (has(1) && has(6) && matches >= 3)) {
    return {
      level: "seek",
      title: "Seek Medical Attention",
      text: "Some of your symptoms can be warning signs. Please see a doctor or visit a hospital promptly."
    };
  }

  if (has(1) && matches >= 2) {
    return {
      level: "possible",
      title: "Possible Dengue",
      text: "Your symptoms are consistent with dengue. Rest, drink fluids, monitor your temperature and consult a doctor soon."
    };
  }

  return {
    level: "low",
    title: "Low Risk",
    text: "Your symptoms don't strongly match dengue. Keep monitoring and see a doctor if they get worse."
  };
}

on("#symptomForm", "submit", async (e) => {

  e.preventDefault();

  const form = e.target;

  const selected = [
    ...form.querySelectorAll("input[name=symptoms]:checked")
  ].map((i) => Number(i.value));

  if (selected.length === 0) {
    alert("Please select at least one symptom.");
    return;
  }

  const r = assessSymptoms(selected);
  const box = $("#screeningResult");

  box.className = `result ${r.level}`;

  box.innerHTML = `
    <h3>${r.title}</h3>
    <p>${r.text}</p>
    <p class="muted" id="screeningSaveMsg">Saving…</p>
    <p class="muted">
      ⚠️ This is an educational screening only — not a medical diagnosis.
    </p>
  `;

  box.hidden = false;

  try {
    const saved = await api.post("/api/screening", {
      result: r.title,
      symptoms: selected
    });

    $("#screeningSaveMsg").textContent = saved.screening_id
      ? `✅ Saved (Screening ID: ${saved.screening_id})`
      : "";

  } catch (err) {
    console.error(err);
    $("#screeningSaveMsg").textContent =
      "Could not save this screening to the database.";
  }
});


/* ---------- 7-day forecast ---------- */

function riskScore(d) {

  const rain = Math.min(d.rainfall / 40, 1);
  const hum = Math.min(Math.max((d.humidity - 60) / 30, 0), 1);
  const temp = 1 - Math.min(Math.abs(d.temp - 29) / 6, 1);
  const cases = Math.min(d.cases / 180, 1);

  return 0.3 * rain + 0.25 * hum + 0.15 * temp + 0.3 * cases;
}

const levelOf = (s) =>
  s >= 0.65 ? "high" : s >= 0.45 ? "medium" : "low";

async function renderForecast(city) {

  const days = await api.forecast(city);

  if (!days || !days.length) {
    return;
  }

  const scored = days.map((d) => ({
    ...d,
    level: d.level || levelOf(riskScore(d))
  }));

  const fEl = $("#forecast");

  if (fEl) {
    fEl.innerHTML = scored.map((d) => `
      <div class="fday ${d.level}">
        <b>${esc(d.date)}</b>
        <div class="bar"></div>
        <small>🦟 ${esc(d.cases)} cases</small>
        <small>🌧️ ${esc(d.rainfall)} mm</small>
        <small>💧 ${esc(d.humidity)}%</small>
        <small>🌡️ ${esc(d.temp)}°C</small>
        <div class="lvl">${cap(d.level)}</div>
      </div>
    `).join("");
  }

  const avg =
    scored.reduce((a, d) => a + riskScore(d), 0) / scored.length;

  const lvl =
    scored.some((d) => d.level === "high") && avg >= 0.5
      ? "high"
      : levelOf(avg);

  const badge = $("#overallRisk");

  if (badge) {
    badge.className = `badge ${lvl}`;
    badge.textContent = `${city} — Dengue Risk: ${lvl.toUpperCase()}`;
  }
}

on("#citySelect", "change", (e) => renderForecast(e.target.value));


/* ---------- Risk map (Leaflet) ---------- */

const COLORS = {
  low: "#22a06b",
  medium: "#f0a020",
  high: "#d93a3a"
};

async function initMap() {

  if (!$("#riskMap") || typeof L === "undefined") {
    return;
  }

  const map = L.map("riskMap").setView([23.79, 90.39], 11);

  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18,
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);

  const areas = await api.areas();

  areas.forEach((a) => {
    L.circle([a.lat, a.lng], {
      radius: 1600,
      color: COLORS[a.level],
      fillColor: COLORS[a.level],
      fillOpacity: 0.35,
      weight: 2
    })
      .addTo(map)
      .bindPopup(
        `<b>${esc(a.name)}</b><br>Risk: ${cap(a.level)}<br>Cases: ${esc(a.cases)}`
      );
  });

  const reports = await api.reports();

  reports
    .filter((r) => r.latitude && r.longitude)
    .forEach((r) => {
      L.circleMarker(
        [parseFloat(r.latitude), parseFloat(r.longitude)],
        {
          radius: 8,
          color: "#2563eb",
          fillOpacity: 0.9
        }
      )
        .addTo(map)
        .bindPopup(
          `<b>Reported Site</b><br>${esc(r.location)}<br>${esc(r.description)}`
        );
    });
}


/* ---------- Breeding-site reporting ---------- */

function showReportMsg(text, type) {
  const msg = $("#reportMsg");

  if (!msg) {
    return;
  }

  msg.hidden = false;
  msg.className = type ? `msg ${type}` : "muted";
  msg.textContent = text;
}

// "Use my location" button
on("#geoBtn", "click", () => {

  if (!navigator.geolocation) {
    showReportMsg("Geolocation is not supported on this device.");
    return;
  }

  showReportMsg("Getting your location…");

  navigator.geolocation.getCurrentPosition(
    (p) => {
      const lat = p.coords.latitude;
      const lng = p.coords.longitude;

      $("#lat").value = lat;
      $("#lng").value = lng;

      if (!$("#locInput").value) {
        $("#locInput").value = `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      }

      showReportMsg("📍 Location added.");
    },
    () => {
      showReportMsg("Couldn't get location automatically. Please type the location name.");
    }
  );
});

// Photo preview + size check
on("#photoInput", "change", (e) => {

  const file = e.target.files[0];
  const preview = $("#photoPreview");

  if (!preview) {
    return;
  }

  if (!file) {
    preview.hidden = true;
    return;
  }

  if (file.size > 5 * 1024 * 1024) {
    showReportMsg("Photo must be 5 MB or smaller.", "error");
    e.target.value = "";
    preview.hidden = true;
    return;
  }

  preview.src = URL.createObjectURL(file);
  preview.hidden = false;
});

const reportForm = $("#reportForm");

if (reportForm) {

  reportForm.addEventListener("submit", async (e) => {

    e.preventDefault();

    const form = e.target;
    const btn = form.querySelector("button[type=submit]");

    btn.disabled = true;

    try {
      const res = await api.post("/api/reports", new FormData(form), true);

      showReportMsg(
        `✅ Thank you! Report submitted successfully (ID: ${res.report_id}).`,
        "success"
      );

      form.reset();

      if ($("#photoPreview")) {
        $("#photoPreview").hidden = true;
      }

    } catch (err) {
      console.error(err);
      showReportMsg(`❌ ${err.message || "Submission failed. Please try again."}`, "error");

    } finally {
      btn.disabled = false;
    }
  });
}


/* ---------- Awareness ---------- */

async function renderArticles() {

  if (!$("#articles")) {
    return;
  }

  const list = await api.articles();

  if (!list.length) {
    $("#articles").innerHTML = `<p class="muted">No awareness content yet.</p>`;
    return;
  }

  $("#articles").innerHTML = list.map((a) => `
    <a
      class="card article-card"
      href="${esc(safeUrl(a.url))}"
      target="_blank"
      rel="noopener noreferrer"
    >
      <small class="muted">
        ${a.type === "Video" ? "🎬" : "📄"}
        ${esc(a.category || a.type || "Info")}
        ${a.source ? " · " + esc(a.source) : ""}
      </small>

      <h3>${esc(a.title)}</h3>
      <p>${esc(a.summary)}</p>

      <span class="go">
        ${a.type === "Video" ? "Watch video" : "Read article"} ↗
      </span>
    </a>
  `).join("");
}


/* ---------- Admin dashboard ---------- */

async function renderAdmin() {

  if (!$("#statReports")) {
    return;
  }

  const [stats, reports] = await Promise.all([
    api.stats(),
    api.reports()
  ]);

  // All counts come from the database (/api/stats)
  $("#statReports").textContent = stats ? stats.reports : reports.length;
  $("#statScreenings").textContent = stats ? stats.screenings : "—";
  $("#statHigh").textContent = stats ? stats.high_risk_areas : "—";

  $("#reportRows").innerHTML = reports.length
    ? reports.slice(0, 10).map((r) => `
        <tr>
          <td>${esc(new Date(r.created_at || Date.now()).toLocaleString([], {
            day: "2-digit",
            month: "short",
            hour: "2-digit",
            minute: "2-digit"
          }))}</td>
          <td>${esc(r.location)}</td>
          <td>${esc(r.description)}</td>
        </tr>
      `).join("")
    : `<tr><td colspan="3" class="muted">No reports yet.</td></tr>`;
}


/* ---------- Init ---------- */

if ($("#overallRisk")) {
  renderForecast("Dhaka");
}

if ($("#riskMap")) {
  initMap();
}

if ($("#articles")) {
  renderArticles();
}

if ($("#preventionCards")) {
  renderPrevention();
}

renderAdmin();
/* ---------- Care content (from PostgreSQL) ---------- */

async function renderCare() {

  if (!$("#warningList")) {
    return;
  }

  const list = await api.get("/api/care", []);

  // Keep the HTML already on the page if the database is empty
  if (!list.length) {
    return;
  }

  const section = (name) => list.filter((i) => i.section === name);

  const fill = (sel, items, tpl) => {
    if (items.length && $(sel)) {
      $(sel).innerHTML = items.map(tpl).join("");
    }
  };

  fill("#warningList", section("warning"), (i) => `<li>${esc(i.title)}</li>`);
  fill("#todoList", section("todo"), (i) => `<li>${esc(i.title)}</li>`);
  fill("#avoidList", section("avoid"), (i) => `<p>${esc(i.title)}</p>`);
}

if ($("#warningList")) {
  renderCare();
}
/* ---------- Navbar (same on every page) ---------- */

async function renderNavbar() {

  const old = document.querySelector("header");
  const oldImg = old ? old.querySelector("img") : null;
  const logoSrc = oldImg ? oldImg.getAttribute("src") : "";

  const pages = [
    ["Home", "/index.html"],
    ["Prevention", "/prevention.html"],
    ["Screening", "/screening.html"],
    ["Care", "/care.html"],
    ["Prediction", "/prediction.html"],
    ["Risk Map", "/map.html"],
    ["Report", "/report.html"],
    ["Awareness", "/awareness.html"],
    ["Admin", "/admin.html"]
  ];

  const current = location.pathname.split("/").pop() || "login.html";

  const linksHtml = pages.map(([label, href]) => {
    const isAdmin = label === "Admin";
    const active = href.split("/").pop() === current ? "active" : "";

    return `
      <li ${isAdmin ? "hidden data-admin" : ""}>
        <a class="${active}" href="${href}">${label}</a>
      </li>`;
  }).join("");

  const header = document.createElement("header");
  header.className = "dg-header";

  header.innerHTML = `
    <div class="dg-bar">
      <a class="dg-brand" href="/index.html">
        <span class="dg-logo" id="dgLogo">🦟</span>
        <span>DengueGuard</span>
      </a>

      <button class="dg-toggle" id="dgToggle" type="button"
        aria-label="Menu">☰</button>

      <nav class="dg-nav" id="dgNav">
        <ul class="dg-links">${linksHtml}</ul>
        <div class="dg-auth" id="dgAuth"></div>
      </nav>
    </div>
  `;

  // Keep your own logo image if the old navbar had one
  if (logoSrc) {
    const img = document.createElement("img");
    img.src = logoSrc;
    img.alt = "DengueGuard";

    const box = header.querySelector("#dgLogo");
    box.textContent = "";
    box.appendChild(img);
  }

  if (old) {
    old.replaceWith(header);
  } else {
    document.body.prepend(header);
  }

  // Mobile menu
  const nav = header.querySelector("#dgNav");

  header.querySelector("#dgToggle").addEventListener("click", () => {
    nav.classList.toggle("open");
  });

  nav.addEventListener("click", (e) => {
    if (e.target.tagName === "A") {
      nav.classList.remove("open");
    }
  });

  // Login / Register (right side) or user name + Logout
  const auth = header.querySelector("#dgAuth");
  let me = { loggedIn: false };

  try {
    const r = await fetch("/api/me");
    me = await r.json();
  } catch (e) {
    console.warn("Could not check login status", e);
  }

  if (me.loggedIn) {

    auth.innerHTML = `
      <span class="dg-user"></span>
      <button class="dg-btn" id="dgLogout" type="button">Logout</button>
    `;

    auth.querySelector(".dg-user").textContent = "Hi, " + me.user.name;

    auth.querySelector("#dgLogout").addEventListener("click", async () => {
      try {
        await fetch("/api/logout", { method: "POST" });
      } catch (e) {}

      location.href = "/login.html";
    });

    if (me.user.role === "admin") {
      const li = header.querySelector("[data-admin]");
      li.hidden = false;
      li.querySelector("a").classList.add("admin-visible");
    }

  } else {

    auth.innerHTML = `
      <a class="dg-btn" href="/login.html">Login</a>
      <a class="dg-btn solid" href="/register.html">Register</a>
    `;
  }
}

renderNavbar();