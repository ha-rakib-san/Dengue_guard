const express = require("express");
const { Pool } = require("pg");
const path = require("path");
const bcrypt = require("bcrypt");
const session = require("express-session");

const app = express();
const PORT = 3000;

// ==================== DATABASE ====================

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "DengueGuard",
    password: "ARSdengue@rakib",
    port: 5432
});

// ==================== MIDDLEWARE ====================

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: "change-this-to-a-long-random-text-2026",
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: "lax",
        maxAge: 2 * 60 * 60 * 1000
    }
}));

// ==================== FRONTEND ====================

const frontendPath = path.join(
    __dirname,
    "dengue_guard",
    "dengu guard"
);

console.log("Frontend Path:", frontendPath);

// ==================== FRONTEND PAGES ====================

// Website open → Login
app.get("/", (req, res) => {
    res.sendFile(path.join(frontendPath, "login.html"));
});

// Login
app.get("/login.html", (req, res) => {
    res.sendFile(path.join(frontendPath, "login.html"));
});

// Register
app.get("/register.html", (req, res) => {
    res.sendFile(path.join(frontendPath, "register.html"));
});

// Homepage
app.get("/index.html", (req, res) => {
    res.sendFile(path.join(frontendPath, "index.html"));
});

// ==================== ADMIN PROTECTION ====================

function requireAdmin(req, res, next) {
    if (!req.session.user || req.session.user.role !== "admin") {
        return res.status(403).json({
            message: "Admin access required."
        });
    }

    next();
}

// Must be BEFORE express.static
app.get("/admin.html", (req, res) => {
    if (!req.session.user || req.session.user.role !== "admin") {
        return res.redirect("/login.html");
    }

    res.sendFile(path.join(frontendPath, "admin.html"));
});

// Static files (index.html automatically serve বন্ধ করা হয়েছে)
app.use(express.static(frontendPath, {
    index: false
}));

// ==================== HEALTH ====================

app.get("/api/health", (req, res) => {
    res.json({
        success: true,
        message: "DengueGuard server is running."
    });
});

// ==================== DATABASE TEST ====================

app.get("/db-test", async (req, res) => {
    try {
        const result = await pool.query("SELECT NOW() AS now");

        res.json({
            success: true,
            message: "Database connected successfully.",
            time: result.rows[0].now
        });

    } catch (error) {
        console.error("DB TEST ERROR:", error.message);

        res.status(500).json({
            success: false,
            message: "Database connection failed.",
            error: error.message
        });
    }
});

// ==================== REGISTER ====================

app.post("/api/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                message: "Name, email and password are required."
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                message: "Password must be at least 6 characters."
            });
        }

        const cleanName = name.trim();
        const cleanEmail = email.trim().toLowerCase();

        const existing = await pool.query(
            `SELECT user_id
             FROM users
             WHERE LOWER(email) = $1`,
            [cleanEmail]
        );

        if (existing.rows.length > 0) {
            return res.status(409).json({
                message: "Email already registered."
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const result = await pool.query(
            `INSERT INTO users
                (name, email, password, role)
             VALUES
                ($1, $2, $3, $4)
             RETURNING
                user_id, name, email, role, created_at`,
            [
                cleanName,
                cleanEmail,
                hashedPassword,
                "user"
            ]
        );

        res.status(201).json({
            message: "Registration successful.",
            user: result.rows[0]
        });

    } catch (error) {
        console.error("REGISTER ERROR:", error.message);

        if (error.code === "23505") {
            return res.status(409).json({
                message: "Email already registered."
            });
        }

        res.status(500).json({
            message: "Registration failed.",
            error: error.message
        });
    }
});

// ==================== LOGIN ====================

app.post("/api/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                message: "Email and password are required."
            });
        }

        const cleanEmail = email.trim().toLowerCase();

        const result = await pool.query(
            `SELECT
                user_id,
                name,
                email,
                password,
                role
             FROM users
             WHERE LOWER(email) = $1`,
            [cleanEmail]
        );

        if (result.rows.length === 0) {
            return res.status(401).json({
                message: "Invalid email or password."
            });
        }

        const user = result.rows[0];

        const match = await bcrypt.compare(
            password,
            user.password
        );

        if (!match) {
            return res.status(401).json({
                message: "Invalid email or password."
            });
        }

        req.session.user = {
            user_id: user.user_id,
            name: user.name,
            email: user.email,
            role: user.role
        };

        res.json({
            message: "Login successful.",
            user: {
                user_id: user.user_id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });

    } catch (error) {
        console.error("LOGIN ERROR:", error.message);

        res.status(500).json({
            message: "Login failed.",
            error: error.message
        });
    }
});

// ==================== LOGOUT ====================

app.post("/api/logout", (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            return res.status(500).json({
                message: "Logout failed."
            });
        }

        res.json({
            message: "Logout successful."
        });
    });
});

// ==================== SYMPTOMS ====================

app.get("/api/symptoms", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM symptoms
             ORDER BY symptom_id`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("SYMPTOMS ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch symptoms.",
            error: error.message
        });
    }
});

// ==================== SCREENING ====================

app.post("/api/screening", async (req, res) => {
    try {
        const { symptoms } = req.body;

        if (!Array.isArray(symptoms)) {
            return res.status(400).json({
                message: "Symptoms must be an array."
            });
        }

        const symptomCount = symptoms.length;

        let result;

        if (symptomCount >= 5) {
            result = "Seek Medical Attention";
        } else if (symptomCount >= 3) {
            result = "Possible Dengue";
        } else {
            result = "Low Risk";
        }

        const saved = await pool.query(
            `INSERT INTO screening_results
                (symptom_count, result)
             VALUES
                ($1, $2)
             RETURNING *`,
            [symptomCount, result]
        );

        res.json({
            message: "Screening completed.",
            result: saved.rows[0]
        });

    } catch (error) {
        console.error("SCREENING ERROR:", error.message);

        res.status(500).json({
            message: "Screening failed.",
            error: error.message
        });
    }
});

// GET SCREENING RESULTS

app.get("/api/screening", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM screening_results
             ORDER BY created_at DESC`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("GET SCREENING ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch screening results.",
            error: error.message
        });
    }
});

// ==================== PREVENTION ====================

app.get("/api/prevention", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM prevention_content
             ORDER BY id`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("PREVENTION ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch prevention content.",
            error: error.message
        });
    }
});

// ==================== CARE ====================

app.get("/api/care", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM prevention_content
             ORDER BY id`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("CARE ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch care content.",
            error: error.message
        });
    }
});

// ==================== REPORTS ====================

app.post("/api/reports", async (req, res) => {
    try {
        const {
            location,
            description,
            latitude,
            longitude
        } = req.body;

        if (!location) {
            return res.status(400).json({
                message: "Location is required."
            });
        }

        const result = await pool.query(
            `INSERT INTO breeding_reports
                (location, description, latitude, longitude)
             VALUES
                ($1, $2, $3, $4)
             RETURNING *`,
            [
                location,
                description || null,
                latitude || null,
                longitude || null
            ]
        );

        res.status(201).json({
            message: "Report submitted successfully.",
            report: result.rows[0]
        });

    } catch (error) {
        console.error("REPORT ERROR:", error.message);

        res.status(500).json({
            message: "Failed to submit report.",
            error: error.message
        });
    }
});

// GET REPORTS

app.get("/api/reports", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM breeding_reports
             ORDER BY created_at DESC`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("GET REPORTS ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch reports.",
            error: error.message
        });
    }
});

// ==================== AWARENESS ====================

app.get("/api/awareness", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM awareness_content`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("AWARENESS ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch awareness content.",
            error: error.message
        });
    }
});

// ADD AWARENESS (admin only)

app.post("/api/awareness", requireAdmin, async (req, res) => {
    try {
        const { title, content } = req.body;

        if (!title || !content) {
            return res.status(400).json({
                message: "Title and content are required."
            });
        }

        const result = await pool.query(
            `INSERT INTO awareness_content
                (title, content)
             VALUES
                ($1, $2)
             RETURNING *`,
            [title, content]
        );

        res.status(201).json({
            message: "Awareness content added.",
            content: result.rows[0]
        });

    } catch (error) {
        console.error("ADD AWARENESS ERROR:", error.message);

        res.status(500).json({
            message: "Failed to add awareness content.",
            error: error.message
        });
    }
});

// ==================== RISK AREAS ====================

app.get("/api/risk-areas", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM risk_zones
             ORDER BY zone_id`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("RISK AREA ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch risk areas.",
            error: error.message
        });
    }
});

// ==================== FORECAST ====================

app.get("/api/forecast", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *
             FROM environmental_data
             ORDER BY date`
        );

        res.json(result.rows);

    } catch (error) {
        console.error("FORECAST ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch forecast data.",
            error: error.message
        });
    }
});

// ==================== STATISTICS (admin only) ====================

app.get("/api/stats", requireAdmin, async (req, res) => {
    try {
        const users = await pool.query(
            `SELECT COUNT(*) FROM users`
        );

        const reports = await pool.query(
            `SELECT COUNT(*) FROM breeding_reports`
        );

        const screenings = await pool.query(
            `SELECT COUNT(*) FROM screening_results`
        );

        const cases = await pool.query(
            `SELECT COUNT(*) FROM dengue_cases`
        );

        res.json({
            users: Number(users.rows[0].count),
            reports: Number(reports.rows[0].count),
            screenings: Number(screenings.rows[0].count),
            cases: Number(cases.rows[0].count)
        });

    } catch (error) {
        console.error("STATS ERROR:", error.message);

        res.status(500).json({
            message: "Failed to fetch statistics.",
            error: error.message
        });
    }
});

// ==================== UPDATE REPORT STATUS (admin only) ====================

app.patch("/api/reports/:id/status", requireAdmin, async (req, res) => {
    try {
        const { status } = req.body;
        const { id } = req.params;

        if (!status) {
            return res.status(400).json({
                message: "Status is required."
            });
        }

        const result = await pool.query(
            `UPDATE breeding_reports
             SET status = $1
             WHERE report_id = $2
             RETURNING *`,
            [status, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                message: "Report not found."
            });
        }

        res.json({
            message: "Report status updated.",
            report: result.rows[0]
        });

    } catch (error) {
        console.error("UPDATE REPORT ERROR:", error.message);

        res.status(500).json({
            message: "Failed to update report status.",
            error: error.message
        });
    }
});

// ==================== API 404 ====================

app.use("/api", (req, res) => {
    res.status(404).json({
        message: "API endpoint not found."
    });
});

// ==================== ERROR HANDLER ====================

app.use((error, req, res, next) => {
    console.error("SERVER ERROR:", error.message);

    res.status(500).json({
        message: "Internal server error.",
        error: error.message
    });
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
    console.log("=================================");
    console.log("DengueGuard Server Started");
    console.log("=================================");
    console.log(`Home/Login : http://localhost:${PORT}/`);
    console.log(`Login      : http://localhost:${PORT}/login.html`);
    console.log(`Register   : http://localhost:${PORT}/register.html`);
    console.log(`Homepage   : http://localhost:${PORT}/index.html`);
    console.log(`DB Test    : http://localhost:${PORT}/db-test`);
    console.log("=================================");
});